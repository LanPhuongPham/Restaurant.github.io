
// Modal

var modal_ctm = document.getElementById('simpleModal');

var modal_ty = document.getElementById('simpleModal02');

var submitButton = document.getElementById('submitbtn');
submitButton.addEventListener('click', submitBooking);

var closeModalButton = document.getElementById('thanks_closeBtn');
closeModalButton.addEventListener('click', closeThanks);


function submitBooking() {
    closeModal();
    openThanks();

}

var modalBtn = document.getElementById('modalBtn');
var closeB = document.getElementsByClassName('closeBtn')[0];


// Music Player

var playBtn = document.getElementById('playbutton');
var pauseBtn = document.getElementById('pausebutton');

var play = document.getElementById('playbutton');
var stop = document.getElementById('pausebutton');

modalBtn.addEventListener('click', openModal);
closeB.addEventListener('click', closeModal);


play.addEventListener('click', playFile);
stop.addEventListener('click', pauseFile);

playBtn.addEventListener('click', playMusic);
pauseBtn.addEventListener('click', pauseMusic);

function playMusic() {
    pauseBtn.style.display = 'block';
    playBtn.style.display = 'none';
}

function pauseMusic() {
    playBtn.style.display = 'block';
    pauseBtn.style.display = 'none';
}
function playFile() {
    $("#mp3File")[0].play();
}
function pauseFile() {
    $("#mp3File")[0].pause();
}

// Modal
function openModal() {
    modal_ctm.style.display = 'block';
}

function closeModal() {
    modal_ctm.style.display = 'none';
}

function openThanks() {
    modal_ty.style.display = 'block';
}

function closeThanks() {
    modal_ty.style.display = 'none';
}


// navigaton bar
const selectElement = (element) => document.querySelector(element);

selectElement('.menu-icons').addEventListener('click', () => {
    selectElement('nav').classList.toggle('active');
});